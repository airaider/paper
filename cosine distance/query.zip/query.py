#####################
##Query 입력을 받고##
##형태소 분석하여  ##
##feature vectorize##
#####################
# coding=<utf-8>

from konlpy.tag import Kkma
import numpy as np
from scipy import spatial

#####################
##feature Lists    ##
#####################


#feature lists : 각 feature의 값을 결정할 단어(유의어) 모음
sad = ['신파', '상처', '치유', '슬프','초라','비극','통탄', '애석', '원통', '비참', '애통', '애처로', '우울', '아프', '서럽', '침통', '비통', '비탄', '애틋', '서글프', '원통', '섧', '눈물', '침울', '무력', '버림받', '그림자', '그늘', '걱정', '근심', '시한부', '이별', '감성적', '싹트']
horror = ['오싹', '시체', '잡아먹', '엽기', '정체불명', '묶이', '자살', '고문','살해', '괴담', '탈출', '살점', '끔찍하', '찌푸리', '질색', '죽이려','공포', '불안', '경악', '두려', '긴장', '숨통', '호러', '무서', '겁','주저', '오금', '가위', '악몽', '불안전', '위협', '살인', '살벌', '소름', '귀신', '괴물', '살인마', '실종', '흉가', '잔인','잔혹', '참혹', '참상','고어', '하드코어', '끔찍', '징그러', '흉하', '소름', '역겨', '벌레', '썩은', '흉측', '살인', '쏘우', '복수', '구역질', '토', '피', '살인']
action = ['악당', '미션', '스파이', '간첩', '007', '경찰','대역', '스턴트', '액션', '대규모', '세트장', '헐리우드', '훈련' ]
family = ['가문', '물려받', '노총각','고명딸','명절', '휴먼', '성장','소년','소녀','수련','가족','일족','집','혈통','종족','가구','친척','혈연','관계','자손','가정','아들','딸', '아버지', '어머니','아빠','엄마','부부','남편','아내','결혼','러브','이혼','임신','불임', '할아버지', '할머니', '손자', '손녀', '손주', '이모', '삼촌', '조카', 'love', 'affair', '감동']
futuristic = ['재난', '우주인', '산소','지구', '우주','미래','과학','외계인','행성', '블랙홀']
love = ['멜로', '운명적', '만남', '짝사랑', '감동','로맨스','사랑','연인','호감','소중','매력','로맨틱','러브','애정','첫눈','이끌리','감정','남녀','관계','남편','아내','친분','재회','첫만남','결혼','러브','동성','성적','이별','애원','섹스','마음', '첫사랑', '행복', '낭만적', '연애관']
hero = ['거대','화려','넘치','장엄','현란','압도적','아이맥스', '블록버스터', '특수', '스케일', '분장','효과', '활약', '파트너','정의', '종말', '영웅','용맹','용기','대담','불굴','씩씩','히어로','마블','디씨','캡틴','리더','지도자','인도자','구출','악당', 'DC', 'Marvel']
comedy = ['코미디', '유머', '배꼽 잡는', '명절', '웃기', '재미있는', '웃으', '유쾌', '떠들썩', '즐거운']
queer = ['동성애', '게이', '레즈', '레즈비언', '트렌스젠더', '퀴어', '동성']
feminism = ['여권','여성','페미니즘', '양성', '페미']
time_travel = ['타임', '돌아가', '퓨처', '타임머신', '시간여행', '미래']
school = ['성적','청춘','성장', '명량', '고딩', '고등학생', '고등학교', '학교', '성장통', '성장기', '선생님', '학생', '교생', '교복', '사춘기', '짝사랑', '학원물', '청춘', '첫사랑']
anime = ['공주','애니', '극장판', '애니메이션', '캐릭터', '성우', '더빙', '어린이', '초등학생', '만화', 'TV시리즈']

stops = ["★★★★★", "★★★★", "★★★", "★★", "★", '있', '하', '것', '들', '그', '되', '수', '이', '보', '않', '없', '나', '사람', '주', '아니', '등', '같', '우리', '때', '년', '가', '한', '지', '대하', '오', '말', '일', '그렇', '위하', '때문', '그것', '두', '말하', '알', '그러나', '받', '못하', '일', '그런', '또', '문제', '더', '사회', '많', '그리고', '좋', '크', '따르', '중', '나오', '가지', '씨', '시키', '만들', '지금', '생각하', '그러', '속', '하나', '집', '살', '모르', '적', '월', '데', '자신', '안', '어떤', '내', '내', '경우', '명', '생각', '시간', '그녀', '다시', '이런', '앞', '보이', '번', '나', '다른', '어떻', '개', '전', '들', '사실', '이렇', '점', '싶', '말', '정도', '좀', '원', '잘', '통하', '소리', '놓']




#####################
##featurizer 함수들##
#####################

# feature 항목 형태소화
def featurizer(feat):
    featStr = ','.join(feat)
    feat = morphy(featStr)
    feat = set(feat)
    print(feat)
    return feat


# In[116]:


#stopword: 2글자 이상 단어 중 필요 없는 단어 계속 추가해서 필터링!
stop = ["있다","다는","은데","특히","있었","동안","면서","을까","해하","어떤","한때","어야","듯이","ㄴ다",'Story',"cinepark","co","kr","Review","ㄴ데"]
stop.append(stops)


# ### morphy : 리뷰에서  형태소 분석

# In[45]:


def morphy(review):
    kkma = Kkma()
    morphs = kkma.morphs(review)
    morphs = [w for w in morphs if ((w not in stop) and (len(w)>1))]#or w == '.' or w == '!' or w == '?'))]
    
    return morphs


# ### feature detecter : 
# 주어진 feature내 유사어를 형태소에서 찾아서 수를 리턴

# In[47]:


#feat은 sad, horror 같은 feature 유의어 사전
#mor는 사용할 morphs (리뷰)
def featureDetector(feat, mor):
    cnt = 0
    for w in mor:
        if w in feat:
            cnt+=1
    return cnt


# ### feature Normalizer:
# Detect한 feature를 정규화

# In[28]:


def featureNormalization(feature):
    total = 0
    for i in range(len(feature)):total += feature[i]
    for i in range(len(feature)):feature[i] /= total
    return feature


# ### feture vectorizer :
# 추출한 feature를 해당 영화의 feature vector화 한다.
# 추가로 정규화까지!

# In[117]:


def featureVectorizer(morphs):
    
    featureVector = []
    
    featureVector.append(featureDetector(sad, morphs))
    featureVector.append(featureDetector(horror, morphs))
    featureVector.append(featureDetector(action, morphs))
    featureVector.append(featureDetector(family, morphs))
    featureVector.append(featureDetector(futuristic, morphs))
    featureVector.append(featureDetector(love, morphs))
    featureVector.append(featureDetector(hero, morphs))
    featureVector.append(featureDetector(comedy, morphs))
    featureVector.append(featureDetector(queer, morphs))
    featureVector.append(featureDetector(feminism, morphs))
    featureVector.append(featureDetector(time_travel, morphs))
    featureVector.append(featureDetector(school, morphs))
    featureVector.append(featureDetector(anime, morphs))
    
    #정규화
    featureNormalization(featureVector)
    
    return featureVector





q = input("query를 입력하세요")
query = morphy(q)
queryFeatureVector = featureVectorizer(query)
print(queryFeatureVector)








review1 = open('data\cine21\내가 살인범이다(2012).txt',encoding='UTF8').read()

morphs1 = morphy(review1)
feature1 = featureVectorizer(morphs1)
print("비교 대상 영화가 가진 vector:")
print(feature1)




result = 1 - spatial.distance.cosine(feature1, queryFeatureVector)
print("입력된 query와 영화의 비교 결과:")
print(result)




